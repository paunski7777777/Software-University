﻿namespace SIS.MvcFramework.ViewEngine
{
    public class ErrorViewModel
    {
        public string Error { get; set; }
    }
}
