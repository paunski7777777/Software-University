﻿using SIS.Framework.Controllers;

namespace PANDA.App.Controllers
{
    public class BaseController : Controller
    {
    }
}
