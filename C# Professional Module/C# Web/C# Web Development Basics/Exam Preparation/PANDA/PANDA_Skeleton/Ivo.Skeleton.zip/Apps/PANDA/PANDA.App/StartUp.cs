﻿using SIS.Framework.Api;

namespace PANDA.App
{
    public class StartUp : MvcApplication
    {
    }
}
