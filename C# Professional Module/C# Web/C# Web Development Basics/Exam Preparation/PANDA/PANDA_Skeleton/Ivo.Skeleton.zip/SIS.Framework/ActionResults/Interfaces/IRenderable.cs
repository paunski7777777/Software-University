﻿namespace SIS.Framework.ActionResults
{
    public interface IRenderable
    {
        string Render();
    }
}
